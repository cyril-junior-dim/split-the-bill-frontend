package pl.softstone;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import pl.softstone.splitthebill.R;

public class FriendActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
    }


}